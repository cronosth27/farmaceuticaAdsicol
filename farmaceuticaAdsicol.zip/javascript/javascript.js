alert('farmaceutica adsicol,su farmaceutica amiga');
